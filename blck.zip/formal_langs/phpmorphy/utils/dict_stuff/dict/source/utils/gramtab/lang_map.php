<?php
return array(
	'ru_ru' => 'rus.xml',
	'rus' => 'rus.xml',
	
	'en_en' => 'eng.xml',
	'eng' => 'eng.xml',
	
	'de_de' => 'ger.xml',
	'ger' => 'ger.xml',
	
	// for all others
	false => 'unk.xml'
);