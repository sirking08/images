<?php
$namespacetree = array(
	'std' => array(
		'vector' => array()
	)
);

$string = "long double";