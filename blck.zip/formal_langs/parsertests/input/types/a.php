<?php
$namespacetree = array(
	'a' => array(
	)
);

$string = "a";