<?php
$namespacetree = array(
	'a' => array(
	)
);

$string = "typedef int (a::*f)(double, double);  f m = &a::method;";