<?php
$namespacetree = array(
	'a' => array(
	)
);

$string = "int (**(*f)(double, int))(double, double) = null;";