<?php
$namespacetree = array(
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "int k = j / h + t + o - r ; bool g = kill = live ;";