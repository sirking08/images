<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "
	class A 
	{
		inline int m1()
		{
			return 2;
		}
		virtual void m2()
		{
			
		}
		inline virtual void m3()
		{
			
		}
	};
";