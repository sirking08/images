<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "switch(a) { case 1: { int test = a + b; } case 2: a+=x; default: a += x * 2; };";