<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "int k [ 5 ] = { 1 , 2 , 4 , 3 , 0 } ;";