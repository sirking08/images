<?php
$namespacetree = array(
	'a' => array(
	)
);

$string = "typedef int (**(*f)(double, int))(double, double);  f m;";