<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * The mass_unenrolment_created event.
 *
 * File         mass_unenrolment_created.php
 * Encoding     UTF-8
 *
 * @package     local_mass_enroll
 *
 * @copyright   2012 onwards Patrick Pollet
 * @copyright   2015 onwards R.J. van Dongen <rogier@sebsoft.nl>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_mass_enroll\event;
defined('MOODLE_INTERNAL') || die();

/**
 * The mass_unenrolment_created event class.
 *
 * @property-read array $other {
 *      Extra information about event.
 *
 *      - PUT INFO HERE
 * }
 *
 * @since     Moodle 2.7
 *
 * @package     local_mass_enroll
 *
 * @copyright   2012 onwards Patrick Pollet
 * @copyright   2015 onwards R.J. van Dongen <rogier@sebsoft.nl>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/
class mass_unenrolment_created extends \core\event\base {

    /**
     * Override in subclass.
     *
     * Set all required data properties:
     *  1/ crud - letter [crud]
     *  2/ edulevel - using a constant self::LEVEL_*.
     *  3/ objecttable - name of database table if objectid specified
     *
     * Optionally it can set:
     * a/ fixed system context
     *
     * @return void
     */
    protected function init() {
        $this->data['crud'] = 'c';
        $this->data['edulevel'] = self::LEVEL_OTHER;
        $this->data['objecttable'] = 'course';
    }

    /**
     * Returns localised event name.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('event:massunenrolcreated', 'local_mass_enroll');
    }

    /**
     * Returns non-localised event description with id's for admin use only.
     *
     * @return string
     */
    public function get_description() {
        return "The user with id {$this->userid} performed a mass unenrolment in the course with id {$this->objectid}.";
    }

    /**
     * Returns relevant URL.
     *
     * @return \moodle_url
     */
    public function get_url() {
        global $CFG;
        return new \moodle_url($CFG->wwwroot . '/local/mass_enroll/mass_unenroll.php', array('id' => $this->courseid));
    }

    /**
     * Return legacy logdata.
     *
     * @return null|array of parameters to be passed to legacy add_to_log() function.
     */
    public function get_legacy_logdata() {
        // Override if you are migrating an add_to_log() call.
        // Path must be relative to 'module name', here 'course'.
        // Rev 12/11/2014 : some core function (get_recent_enrolments()) expect the
        // info field of log record to be integer when action field is 'enrol'.
        // This produced fatal SQL errors with PostGres see https://github.com/patrickpollet/moodle_local_mass_enroll/issues/5
        // so we changed action value from 'unenrol' to 'massunenrol'.
        return array($this->courseid, 'course', 'massunenroll',
            '../local/mass_enroll/mass_enroll.php?id=' . $this->courseid,
            $this->other['info']);
    }

    /**
     * Custom validation.
     *
     * @throws \coding_exception
     * @return void
     */
    protected function validate_data() {
        parent::validate_data();

        if (empty($this->courseid)) {
            throw new \coding_exception('The \'courseid\' must be set.');
        }

        if (!isset($this->other['info'])) {
            throw new \coding_exception('The \'info\' field must be set in \'other\'.');
        }
    }

}