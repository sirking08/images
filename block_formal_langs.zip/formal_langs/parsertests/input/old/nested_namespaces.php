<?php
$namespacetree = array(
	'vector' => array(
        
	),
    'std' => array(
        'vector' => array(
            'inner' => array(
            )
        )
    )
);

$string = "namespace A { namespace B { namespace C  { void main() { return; } int r; }}} int m; int o;";