{
    "moodle-atto_fontfamily-button": {
        "requires": [
            "node"
        ]
    }
}
