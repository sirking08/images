
# Automated testing

This project uses behat testing to validate the code.

    mooodle-atto_wiris:
    - 14 scenarios (14 passed)
    - 284 steps (284 passed)

| Test file  | Local execution  | TravisCI |
|---|---| - |
| atto_changeEditor.feature | OK | - |
| atto_chemistryModal.feature | OK | - |
| atto_dbClickNonFormulaImages.feature | OK | - |
| atto_emptyLatex.feature | OK | - |
| atto_filterActivityDisabled.feature | OK | - |
| atto_filterCourseEnabled.feature | OK |
| atto_frenchQuotes.feature | OK | - |
| atto_modalDragFocus.feature | OK | - |
| atto_modal.feature | OK | - |
| atto_multipleEditorsTextAarea.feature | OK | - |
| atto_restoreDraft.feature | OK | - |
| atto_textArea.feature | OK | - |
| atto_UTF-32.feature | OK | - |