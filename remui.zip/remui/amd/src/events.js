"use strict";
define([], function() {
    return {
        SECTION_ADDED: 'theme_remui-frontpage-section-added',
        SECTION_UPDATED: 'theme_remui-frontpage-section-updated',
    };
});